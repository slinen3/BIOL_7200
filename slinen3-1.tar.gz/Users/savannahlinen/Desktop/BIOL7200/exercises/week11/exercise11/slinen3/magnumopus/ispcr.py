import subprocess
import os
import sys
import tempfile
from collections import defaultdict
from typing import List, Tuple

def step_one(primer_file: str, assembly_file: str) -> List[List[str]]:
	hits = find_annealing(primer_file, assembly_file)
	good_hits = filter_blast(hits)
	sorted_hits = sorted(good_hits, key=lambda x: (x[1], int(x[8])))

	return sorted_hits


def step_two(
	sorted_hits: List[str],
	max_amplicon_size: int
) -> List[Tuple[List[str]]]:
	hit_pairs = identify_paired_hits(sorted_hits, max_amplicon_size)
	return hit_pairs

def step_three(hit_pairs: List[Tuple[List[str]]], assembly_file: str) -> str:
	amplicons = get_amplicons(assembly_file, hit_pairs)
	return amplicons


def find_annealing(primer_file: str, assembly_file: str) -> List[str]:
	blast_command = ["blastn"]
	blast_command += ["-query", primer_file]
	blast_command += ["-subject", assembly_file]
	blast_command += ["-task", "blastn-short"]
	blast_command += ["-outfmt", "6 std qlen"]
	blast_result, _ = run_external(blast_command)

	return blast_result


def run_external(command: List[str], stdin=None) -> Tuple[str, str]:
	"""run external command and return stout and stderr
	"""
	if stdin is None:
		result = subprocess.run(command, capture_output=True, text=True)
	else:
		result = subprocess.run(command, capture_output=True, text=True, input=stdin)

	return result.stdout, result.stderr


def filter_blast(blast_output: str) -> List[List[str]]:
	good_hits = []
	for line in blast_output.split("\n"):
		if len(line) == 0:
			continue
		cols = line.split()
		if cols[3] != cols[12]:
			continue
		good_hits.append(cols)

	return good_hits


def identify_paired_hits(
	good_hits: List[List[str]],
	max_amp_size: int
) -> List[Tuple[List[str]]]:
	pairs = []
	for i in range(len(good_hits)-1):
		a_hit = good_hits[i]
		a_start, a_stop = [int(i) for i in a_hit[8:10]]
		a_dir = "fwd" if a_start < a_stop else "rev"
		for j in range(i+1, len(good_hits)):
			b_hit = good_hits[j]
			if a_hit[1] != b_hit[1]: # different contig
				continue

			b_start, b_stop = [int(i) for i in b_hit[8:10]]
			b_dir = "fwd" if b_start < b_stop else "rev"

			if a_dir == b_dir: # same direction
				continue

			if a_start < b_start: # a before b
				if not a_dir == "fwd": # wrong direction
					continue
				if not a_stop > b_start - max_amp_size: # too far
					break ############### continue

				pairs.append((a_hit, b_hit))
				continue

			if not b_dir == "fwd": # wrong direction
				continue
			if not b_stop > a_start - max_amp_size: # too far
				continue

			pairs.append((a_hit, b_hit))
	
	return pairs


def get_amplicons(
	assembly: str,
	hit_pairs: List[Tuple[List[str]]]
) -> str:
	amplicons = []
	bed = []
	for f_hit, r_hit in hit_pairs:
		contig = f_hit[1]
		start = int(f_hit[9])
		end = int(r_hit[9])-1

		bed.append(f"{contig}\t{start}\t{end}\n")

	bed_string = "".join(bed)

	# either use a temp file
	with tempfile.NamedTemporaryFile(mode='w+') as temp:
		temp.write(bed_string)
		temp.seek(0) # move back to beginning of file
		seqtk_command = ["seqtk", "subseq", assembly]
		seqtk_command += [temp.name]
		amplicons, stderr = run_external(seqtk_command)

	# Or use stdin
	# seqtk_command = ["seqtk", "subseq", assembly]
	# seqtk_command += ["-"]
	# amplicons, stderr = run_external(seqtk_command, stdin=bed_string)
	
	return amplicons

def ispcr(primer_file: str, assembly_file: str, max_amplicon_size: int) -> str:

	""" Takes in primer file, assembly file, and max amplicon size and runs steps one through three to get amplicons from the assembly file. 
	Args:
		primer_file (str): Primer file to use in BLAST against the assembly files provided.
		assembly_file (str): Assembly file to be analyzed (FASTA).
		max_amplicaon_size (str): Int representing the maximum allowed size for an amplicon.

	Returns: 
		third_step (list): Amplicons from the assembly file provided. 

	Example Usage:
		amplicons_assembly1 = magnumopus.ispcr(primer_file, assembly, max_amp_size)

	"""

	first_step = step_one(primer_file,assembly_file)
	second_step = step_two(first_step,max_amplicon_size)
	third_step = step_three(second_step,assembly_file)

	return third_step


