from magnumopus.ispcr import (
	step_one,
	step_two,
	step_three,
    ispcr
)
from magnumopus.needleman_wunsch import needleman_wunsch
